// Copyright (C) 2016 and later: Unicode, Inc. and others.
// License & terms of use: http://www.unicode.org/copyright.html
/********************************************************************
 * COPYRIGHT:
 * Copyright (c) 2003-2013, International Business Machines Corporation and
 * others. All Rights Reserved.
 ********************************************************************/

void TestUScriptCodeAPI(void);
void TestHasScript(void);
void TestGetScriptExtensions(void);
void TestScriptMetadataAPI(void);
void TestBinaryValues(void);
